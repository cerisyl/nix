
-- BGAnimations\_shared background\default.lua
	af[#af+1] = LoadActor("./Datum.lua", file)

-- BGAnimations\_shared background\Normal.lua
	self:visible(not ThemePrefs.Get("RainbowMode") and style ~= "SRPG9" and style ~= "Technique" and style ~= "Transistor" and style ~="Datum")
	if ThemePrefs.Get("RainbowMode") or style == "SRPG9" or style == "Technique" or style == "Transistor" or style =="Datum" then

-- BGAnimations\ScreenEvaluation common\Panes\Pane1\Percentage.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum" then
		self:diffusealpha(0.5)
		
-- BGAnimations\ScreenEvaluation common\Panes\Pane2\Percentage.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)

-- BGAnimations\ScreenEvaluation common\Panes\Pane5\default.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)

-- BGAnimations\ScreenEvaluation common\Shared\SongFeatures.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)

-- BGAnimations\ScreenEvaluation common\Shared\TitleAndBanner.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)

-- BGAnimations\ScreenEvaluation common\PerPlayer\Lower\Graphs.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum" then
		self:diffusealpha(0.95)

-- BGAnimations\ScreenEvaluation common\PerPlayer\Lower\default.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- BGAnimations\ScreenEvaluation common\PerPlayer\Lower\PlayerModifiers.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- BGAnimations\ScreenEvaluation common\PerPlayer\Lower\ScatterPlot.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- BGAnimations\ScreenSelectMusic overlay\PerPlayer\DensityGraph.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0.5)
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- BGAnimations\ScreenSelectMusic overlay\SongDescription\SongDescription.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- Graphics\_footer.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum" then
		self:diffusealpha(0)
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Datum" then
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- Graphics\_header.lua
	elseif ThemePrefs.Get("VisualStyle") == "Datum"  then
		self:diffusealpha(0)
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- Graphics\MusicWheelItem Course NormalPart.lua
	if ThemePrefs.Get("VisualStyle") == "SRPG9" or ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Datum" then
	if ThemePrefs.Get("VisualStyle") == "SRPG9" or ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- Graphics\MusicWheelItem SectionCollapsed NormalPart.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then
	
-- Graphics\MusicWheelItem SectionExpanded NormalPart.lua
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then
	if ThemePrefs.Get("VisualStyle") == "Technique" or ThemePrefs.Get("VisualStyle") == "Transistor" or ThemePrefs.Get("VisualStyle") == "Datum" then

-- Scripts\99 SL-ThemePrefs.lua
	local visualStyleChoices = { "❤", "↖", "🐻", "🦆", "😺", "🎃", "🌈", "⭐", "🤔", "🌀", "💾", "🖲" }
	local visualStyleValues  = { "Hearts", "Arrows", "Bears", "Ducks", "Cats", "Spooky", "Gay", "Stars", "Thonk", "Technique", "Datum", "Transistor" }